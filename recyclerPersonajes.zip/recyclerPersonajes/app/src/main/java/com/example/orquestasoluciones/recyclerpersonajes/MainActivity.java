package com.example.orquestasoluciones.recyclerpersonajes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Contenedor> listDatos;
    RecyclerView rezaicler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        listDatos=new ArrayList<>();
        rezaicler=(RecyclerView)findViewById(R.id.recyclerid);
        rezaicler.setLayoutManager(new LinearLayoutManager(this));

        datosfill();

        AdapterDatos adapater=new AdapterDatos(listDatos);
        rezaicler.setAdapter(adapater);

    }
    private void datosfill(){
        listDatos.add(new Contenedor(R.drawable.ic_launcher_background,"pueblo avenida ","3","cadiz","la linea"));
    }
}
