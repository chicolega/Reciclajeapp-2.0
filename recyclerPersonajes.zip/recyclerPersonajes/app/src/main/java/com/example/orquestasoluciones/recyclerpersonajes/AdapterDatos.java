package com.example.orquestasoluciones.recyclerpersonajes;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos> {
    ArrayList<Contenedor> listacontenedores;

    public AdapterDatos(ArrayList<Contenedor> list_Datos) {
        this.listacontenedores = list_Datos;
    }

    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list,null,false);
        return new ViewHolderDatos(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos viewHolderDatos, int i) {
        viewHolderDatos.direccion.setText(listacontenedores.get(i).getDireccion());
        viewHolderDatos.numero.setText(listacontenedores.get(i).getNumero());
        viewHolderDatos.provincia.setText(listacontenedores.get(i).getProvincia());
        viewHolderDatos.localidad.setText(listacontenedores.get(i).getLocalidad());
        viewHolderDatos.imagen.setImageResource(listacontenedores.get(i).getImagen());
    }

    @Override
    public int getItemCount() {
        return listacontenedores.size();
    }

    public class ViewHolderDatos extends RecyclerView.ViewHolder {

        TextView direccion,numero,provincia,localidad;
        ImageView imagen;


        public ViewHolderDatos(@NonNull View itemView) {
            super(itemView);
            direccion=itemView.findViewById(R.id.direccionid);
            numero=itemView.findViewById(R.id.numid);
            provincia=itemView.findViewById(R.id.provinciaid);
            localidad=itemView.findViewById(R.id.localidadaid);
            imagen=itemView.findViewById(R.id.imagenContenedorId);

        }


    }
}
