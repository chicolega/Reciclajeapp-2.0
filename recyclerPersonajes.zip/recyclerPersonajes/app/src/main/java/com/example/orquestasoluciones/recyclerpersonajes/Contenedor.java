package com.example.orquestasoluciones.recyclerpersonajes;

public class Contenedor {

    private int imagen;
    private String direccion;
    private String numero;
    private String provincia;
    private String localidad;


    public Contenedor() {
    }

    public Contenedor(int imagen, String direccion, String numero, String provincia, String localidad) {
        this.imagen = imagen;
        this.direccion = direccion;
        this.numero = numero;
        this.provincia = provincia;
        this.localidad = localidad;
    }

    public int getImagen() {
        return imagen;
    }

    public void setImagen(int imagen) {
        this.imagen = imagen;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }
}
