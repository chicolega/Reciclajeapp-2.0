package com.example.scottowen.reciclajeapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteBD extends SQLiteOpenHelper {

    String sql = "CREATE TABLE Usuario (Nombre TEXT, Apellidos TEXT, Email TEXT, Contrasena TEXT);";


    public SQLiteBD(Context context, String name) {
        super( context, name, null, 1);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Usuario");
        db.execSQL(sql);
    }
}
