package com.example.scottowen.reciclajeapp;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registro extends AppCompatActivity {
    Button finalizar;
    EditText nombreUsuario;
    EditText apellidosUsuario;
    EditText emailUsuario;
    EditText contraseñaUsuario;
    String nombre;
    String apellidos;
    String email;
    String contraseña;
    String contraseñare;
    EditText repetircontraseña;
    boolean verificadoremails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        finalizar = (Button) findViewById(R.id.Registrarbotonregistro);
        nombreUsuario = (EditText) findViewById(R.id.NombreTextoRegistro);
        apellidosUsuario = (EditText) findViewById(R.id.Apellidostextoregistro);
        emailUsuario = (EditText) findViewById(R.id.EmailtextoRegistro);
        contraseñaUsuario = (EditText) findViewById(R.id.contraseñatextoregistro);
        repetircontraseña = (EditText) findViewById(R.id.recontraseñatextoregistro);

    }

    public void hacialogin (View view) {
        Intent intent = new Intent(this, Login.class);
        Button editText = (Button) findViewById(R.id.atrasbotonregistro);
        startActivity(intent);

    }

    public void insertarEnBD(View v){
        nombre = nombreUsuario.getText().toString();
        apellidos = apellidosUsuario.getText().toString();
        email = emailUsuario.getText().toString();
        contraseña = contraseñaUsuario.getText().toString();
        contraseñare=repetircontraseña.getText().toString();

        if(nombre.length() > 0 && apellidos.length() > 0 && email.length() > 0 && contraseña.length() > 0){
            SQLiteBD usuario = new SQLiteBD(this, "BDUsuario");
            SQLiteDatabase db = usuario.getWritableDatabase();

            if(email.contains("@")) {

                db.execSQL("INSERT INTO Usuario (Nombre, Apellidos, Email, Contrasena) VALUES('" + nombre + "', '" + apellidos + "', '" + email + "', '" + contraseña + "')");
                db.close();

                Intent i = new Intent(Registro.this, Login.class);
                startActivity(i);

            }else{
                Toast.makeText(Registro.this, "Email incorrecto", Toast.LENGTH_SHORT).show();
            }
        }
        else{
            Toast.makeText(Registro.this, "Debes rellenar todos los parametros", Toast.LENGTH_SHORT).show();
        }
    }
}
